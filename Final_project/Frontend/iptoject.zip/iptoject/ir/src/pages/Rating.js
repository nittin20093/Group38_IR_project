import { useState } from 'react'
import React from 'react'
import Formsidebar from '../components/Formsidebar'
import Navbar from '../components/Navbar'
import '../styles/City.css'
import { Link, useLocation } from 'react-router-dom'
const City = () => {
    const location = useLocation();
    const propsdata = location.state;
    const [Select,setSelect] = useState();
    console.log(propsdata)
  return (
    <div className='citypage'>
        <Navbar></Navbar>
        <div className='hero'>
            <div className='sidebar1'>
                <div className='sidebar'>
                <div className='sidebaroptions '>
                    Select The City
                </div>
                <div className='sidebaroptions '>
                    Budget
                </div>
                <div className='sidebaroptions '>
                    Amenities
                </div>
                <div className='sidebaroptions active'>
                    Minimum Rating
                </div>
                <div className='sidebaroptions '>
                    Select Some Photos
                </div>
                <div className='sidebaroptions'>
                    Select hotels
                </div>
                <div className='sidebaroptions'>
                    Enjoy
                </div>
             </div>

            </div>
            <div className='sidebar2'>
                <div className='Previnfo'>
                    <span>DELHI</span>
                    <span>Rs 1000 - Rs 2000 per day</span>
                </div>
                <div className='oneline'>
                    <h1 className='title'>What is the Minimum rating you want ?</h1>
                    <div className=''>
                        <select value={Select} onChange={e=>{setSelect(e.target.value)}}>
                            <option value="None">Choose from the list </option>
                            <option value="5"> 5 rating</option>
                            <option value="4-5">4-5 rating</option>
                            <option value="3-4">3-4 rating </option>
                            <option value="2-3">2-3 rating</option>
                        </select>

                    </div>
                    <Link to="/hotels/photos" state={{...propsdata, ...{rating:Select}}}>submit</Link>

                </div>
                
                

            </div>
        </div>
       
    </div>
  )
}

export default City
import React from 'react'
import { Link } from 'react-router-dom'


const Formsidebar = (props) => {
  return (
        <div className='sidebar'>
            <div className='sidebaroptions active'>
                <Link to="/hotels/city">Select The City</Link>
            </div>
            <div className='sidebaroptions '>
                <Link to="/hotels/budget">Budget</Link>
            </div>
            <div className='sidebaroptions'>
                <Link to="/hotels/amenities">Amenities</Link>
            </div>
            <div className='sidebaroptions'>
                <Link to="/hotels/rating">Minimum rating</Link>
            </div>
            <div className='sidebaroptions '>
                <Link to="/hotels/photos">Select Photos</Link>
            </div>
            <div className='sidebaroptions'>
                <Link to="/hotels/hotels">Select Hotels</Link>
            </div>
            <div className='sidebaroptions'>
                <Link to="/hotels/enjoy">Enjoy</Link>
            </div>
        </div>

  )
}

export default Formsidebar
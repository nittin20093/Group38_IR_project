import pandas as pd

df1= pd.read_csv('bangalore_hotel_details631_to_962.csv')
df2= pd.read_csv('bangalore_hotel_details630.csv')

# print(df1, df2)

df=df1.append(df2)

print(df)
df.to_csv('banglore_hotels_details.csv')
import pandas as pd
import json
import ast

df = pd.read_csv('./goa_hotel_details.csv')
print(df)
all_dic=[]
all_keys=[]
loc=[]
rat=[]
name=[]
rev=[]
price=[]
img=[]
rmsize=[]
amen=[]
city=[]
link=[]
i=0
li = list()
while i<len(df['details']):
    dic=df.loc[i].at["details"]
    # print(type(dic))
    # d = json.loads('"'+dic+'"')
    p = ast.literal_eval(dic)
    # i+=1
    # continue
    # print(p)
    for key, value in p.items():
        if key not in all_keys:
            all_keys.append(key)
    
    loc.append(p['Location'])
    rat.append(p['overall_rating'])
    name.append(p['Name'])
    rev.append(p['reviews'])
    price.append(p['price'])
    img.append(p['img_link'])
    rmsize.append(p['room_size'])
    am=p['amenities']
    # print(am)
    am1=[]
    
    for o in range(len(am)):
        if am[o].__contains__('bed'):
            continue
        else:
            am1.append(am[o])

    for m in range(len(am1)):
        # print(am[m])
        if am1[m] ==  'Free Wi-Fi in all rooms!' or am1[m]=='Free Wi-Fi' or am1[m]=='Wi-Fi [free]' or am1[m]=='Mobile hotspot device':
            am1[m]='Free Wi-Fi'
        if am1[m] =='Individual air conditioning' :
            am1[m]='Air conditioning'
        if am1[m] =='Audible alarm' :
            am1[m]='Alarm clock'
        if am1[m] =='Walk-in shower' :
            am1[m]='Shower'
        if am1[m] =='Bathtub' :
            am1[m]='Shower and bathtub'
        if am1[m] =='TV [flat screen]' :
            am1[m]='TV'
        if am1[m] =='Mini bar' :
            am1[m]='Alcohol'
            # print(am[m])
        
    
    
            # print(am[m])
        # print(am[m])
    amen.append(am1)
    city.append(p['city'])
    link.append(p['link'])
    i+=1
    # for i in key:
    #     x=key[i]
    #     print(x)
# m=0
# while m <= len(amen):
#     if amen[m]== "Free Wi-Fi" or "Free Wi-Fi in all rooms!" or "Wi-Fi [free]" or "Mobile hotspot device":
#             amen[m]="Free Wi-Fi"
#     m=m+1
# print("amen is \n", amen)
# for m in range(len(amen)):
#         print("amen[m] is",  amen[m])
#         if amen[m]== "Free Wi-Fi" or "Free Wi-Fi in all rooms!" or "Wi-Fi [free]" or "Mobile hotspot device":
#             amen[m]="Free Wi-Fi"
# print(loc)
# print(rat)
# print(name)
# print(rev)
# print(price)
# print(img)
# print(rmsize)
# print(amen)
# print(city)
# print(link)

# exit()

df['Location']=loc
df['overall_rating']=rat
df['Name']=name
df['reviews']=rev
df['price']=price
df['img_link']=img
df['room_size']=rmsize
df['amenities']=amen
df['city']=city
df['link']=link
# print(df)
# df['Free Wifi']  = li

# print("1 amen", amen)
total_amenities=[]
l=0
while l <= len(amen):
    for j in amen[l]:
        if j not in total_amenities:
            total_amenities.append(j)
        l=l+1
# print("2 amen", amen)
# print(total_amenities)
# print(len(total_amenities))
# df[total_amenities[0]] 


# print(df['amenities'][5])
for each_amenity in total_amenities:
    li_val = list()
    for i in range(len(df)):
        # print(p['amenities'])
        if(each_amenity in df['amenities'][i]):
            li_val.append(1)
        else:
            li_val.append(0)
    df[each_amenity] = li_val

    # print(df['Location'])

df.to_csv('goa_hotels_details_final.csv')


# df.loc[len(df)]=total_amenities


# for i in range(len(total_amenities)):
#     print(total_amenities[i])
#     p=0
#     while p<len(df['details']):
#         for m in range(len(am1)):
#             if am1[m]==total_amenities[i]:
                # print('1')
            # else:

                # print('0')
        # p=p+1
#     colum=total_amenities[i]
#     df['colum']
# print(df)

# print(all_keys)
    # print(key)
    # for k in p:
    #     print(p[k])

    # new_df=pd.DataFrame.from_dict(p)
    # print(new_df)
    # q=[(k, p[k]) for k in p]
    # print(q)
    # for j in q:
    #     r=q[j]
    #     print(r)
        

    # all_dic.append(p)
    # print(i ,p)
    # print(type(p))
    # break
    
# final_dic={k:v for i in all_dic for k,v in i.items()}
 
# print(all_dic)
# print("final dic is", final_dic)
#     dic2=[]
#     dic2.append(dic)
#     new_dic=dic2
#     print(new_dic)
#     print(type(new_dic))
#     # f_dic = ast.literal_eval(new_dic)
#     f_dic=json.loads(new_dic)
#     print(type(f_dic))
#     # key=dic.keys()
#     # print(key)
#     i=i+1



# # for i in df:
# #     dic=df.loc[i].at["details"]
# #     print(dic)

# # col= list(df)
# # for i in df.iterrows():
# #     dic=i
# #     print(i)
# #     print("\n")
# # for i in df['details']:
# #     dic=df['details']
# # df=df1['details']
# # for i in df:
# #     dic=df.loc[i]
# #     print(dic)
# #     break


